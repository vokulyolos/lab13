﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_laba13
{
    public class Employees
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Joing_Date { get; set; }
        public string Gender { get; set; }
        public int Monthly_Salary { get; set; }
    }
}
